***************************************************
*
* ARM Strategic Support Group
*
***************************************************
Title   : Examples ReadME

This directory contains some example programs which 
can be built and run on the ARM Evaluation Board 
AEB-1.

Project   Interrupts      Description
====================================================
Pascal    none...         Prints out a simple 
                          Pascal's Triangle.

Switch    Button          A button interrupt driven 
                          program

Traffic   Button/Timer    Traffic light simulation

****************************************************
* End of Examples ReadME
****************************************************