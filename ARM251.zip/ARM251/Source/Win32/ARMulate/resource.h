//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by armu8dll.rc
//
#define IDD_CONFIG                      101
#define IDC_CLOCKON                     1000
#define IDC_CLOCKOFF                    1001
#define IDC_FPE                         1016
#define IDC_PROCESSOR                   1034
#define IDC_ENDIAN                      1042
#define IDC_BIG_ENDIAN                  1043
#define IDC_CLOCK_SPEED                 1044
#define IDC_SPEED                       1045
#define IDC_CLOCK                       1046
#define IDC_WATCHPOINT                  1047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
