/* bron.h
 * Copyright (c) 1997 Advanced RISC Machines Limited
 * All Rights Reserved
 *
 * RCS $Revision: 1.1 $
 * Checkin $Date: 1997/07/23 13:57:58 $
 * Revising $Author: clavende $
 */

#ifndef BRON_H
#define BRON_H

#include        "dlist.h"

#define         NO_MATCH                0x7f7f7f7f

#endif
